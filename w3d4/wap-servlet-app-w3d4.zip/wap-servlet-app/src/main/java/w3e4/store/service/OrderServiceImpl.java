package w3e4.store.service;

import w3d3.model.User;
import w3e4.store.model.Order;
import w3e4.store.model.OrderDetail;
import w3e4.store.model.Product;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class OrderServiceImpl implements OrderService {
    static List<Order> orders = new ArrayList<>();

    @Override
    public Order makeOrder(User user, List<OrderDetail> orderDetails) {
        Order order = new Order(orderDetails);
        order.setOrderId(UUID.randomUUID().toString());
        order.setUser(user);
        orders.add(order);
        return order;
    }
}
