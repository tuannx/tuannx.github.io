package w3e4.store.service;

import w3d3.model.User;
import w3e4.store.model.Order;
import w3e4.store.model.OrderDetail;
import w3e4.store.model.Product;

import java.util.List;

public interface OrderService {
    Order makeOrder(User user, List<OrderDetail> orderDetails);
}
