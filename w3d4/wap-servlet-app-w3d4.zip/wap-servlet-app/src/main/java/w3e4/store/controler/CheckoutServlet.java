package w3e4.store.controler;

import com.google.gson.Gson;
import w3d3.model.User;
import w3e4.store.model.Order;
import w3e4.store.model.OrderDetail;
import w3e4.store.model.Product;
import w3e4.store.service.OrderService;
import w3e4.store.service.OrderServiceImpl;
import w3e4.store.service.ProductService;
import w3e4.store.service.ProductServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

@WebServlet("/store/product/checkout")
public class CheckoutServlet extends HttpServlet {

    Gson mapper = new Gson();
    ProductService productService = new ProductServiceImpl();
    OrderService orderService = new OrderServiceImpl();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        StringBuilder sb = new StringBuilder();
        BufferedReader reader = req.getReader();
        try {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }
        } finally {
            reader.close();
        }

        String json = sb.toString();
        Map[] order = mapper.fromJson(json, Map[].class);
        System.out.println(order);
        List<OrderDetail> orderDetails = new ArrayList<>();
        Arrays.stream(order).forEach(map -> {
            Product product = productService.getById((String) map.get("productId"));
            OrderDetail orderDetail = new OrderDetail(product, ((Double) map.get("amount")).intValue());
            orderDetails.add(orderDetail);
        });
        Order order1 = orderService.makeOrder((User) req.getSession().getAttribute("user"), orderDetails);
        System.out.println(order1);
        PrintWriter out = resp.getWriter();
        out.print(mapper.toJson(order1));
    }
}
