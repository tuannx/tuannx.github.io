package w3e4.store.controler;

import w3e4.store.service.ProductService;
import w3e4.store.service.ProductServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/store/product/list")
public class ListProductServlet extends HttpServlet {
    ProductService productService = new ProductServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setAttribute("products", productService.listProducts());
        req.getRequestDispatcher("/WEB-INF/store/product/list.jsp")
                .forward(req, resp);
    }
}
