package w3e4.store.model;

import w3d3.model.User;

import java.util.List;
import java.util.stream.Collectors;

public class Order {
    List<OrderDetail> orderDetails;
    User user;
    String orderId;
    int totalMoney;

    public Order(List<OrderDetail> orderDetails) {
        this.orderDetails = orderDetails;
        this.totalMoney = orderDetails.stream()
                .map(orderDetail -> orderDetail.getQuantity() * orderDetail.product.getPrice())
                .collect(Collectors.summingInt(Integer::intValue));
    }

    public List<OrderDetail> getOrderDetails() {
        return orderDetails;
    }

    public void setOrderDetails(List<OrderDetail> orderDetails) {
        this.orderDetails = orderDetails;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public int getTotalMoney() {
        return totalMoney;
    }

    public void setTotalMoney(int totalMoney) {
        this.totalMoney = totalMoney;
    }

    @Override
    public String toString() {
        return "Order{" +
                "user=" + user +
                ", orderId='" + orderId + '\'' +
                ", totalMoney='" + totalMoney + '\'' +
                ", orderDetails=" + orderDetails +
                '}';
    }
}
