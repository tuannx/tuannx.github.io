package w3e4.store.service;

import w3e4.store.model.Product;

import java.util.ArrayList;
import java.util.List;

public class ProductServiceImpl implements ProductService {
    static List<Product> products = new ArrayList<>();

    static {
        products.add(new Product("1", "Ipad", "Ipad 2021", 100, ""));
        products.add(new Product("2", "Iphone", "IPhone 2021", 200, ""));
    }

    @Override
    public List<Product> listProducts() {
        return products;
    }

    @Override
    public Product getById(String id) {
        return products.stream()
                .filter(product -> product.getId().equals(id))
                .findFirst()
                .orElse(null);
    }
}
