package w3e4.store.service;

import w3e4.store.model.Product;

import java.util.List;

public interface ProductService {
    List<Product> listProducts();

    Product getById(String id);
}
