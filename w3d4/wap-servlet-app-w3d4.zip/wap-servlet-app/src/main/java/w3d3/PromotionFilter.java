package w3d3;

import w3d3.model.User;
import w3d3.service.UserService;
import w3d3.service.UserServiceImpl;
import w3d3.util.CryptoUtil;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebFilter(urlPatterns = "/*")
public class PromotionFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpServletRequest = (HttpServletRequest) request;
        boolean promoStored = false;
        for (Cookie cookie : httpServletRequest.getCookies()) {
            try {
                if ("promoted".equals(cookie.getName())) {
                    promoStored = true;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (!promoStored) {
            Cookie promotedCookie = new Cookie("promoted", "promoted");
            Cookie promo = new Cookie("promo", "$100");
            promotedCookie.setMaxAge(10 * 365 * 24 * 60 * 60);
            promo.setMaxAge(30 * 24 * 60 * 60);
            HttpServletResponse httpServletResponse = (HttpServletResponse) response;
            httpServletResponse.addCookie(promotedCookie);
            httpServletResponse.addCookie(promo);
        }
        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {

    }
}
