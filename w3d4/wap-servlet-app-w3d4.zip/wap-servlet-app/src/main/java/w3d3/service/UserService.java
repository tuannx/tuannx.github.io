package w3d3.service;

import w3d3.model.User;

public interface UserService {
    User login(String username, String password);
}
