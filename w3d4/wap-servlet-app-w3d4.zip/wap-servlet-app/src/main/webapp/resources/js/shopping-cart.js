"use strict";
(function () {
  window.onload = function () {
    function addToCart(productId, productName,) {
      console.log("Add " + productId + " productName " + productName);
      let storageCartProducts = localStorage.getItem("cart-products");
      let cartProducts;
      if (storageCartProducts) {
        cartProducts = JSON.parse(storageCartProducts);
        let productIndex = cartProducts.findIndex(p => p.productId === productId);
        if (productIndex >= 0) {
          cartProducts[productIndex].amount = cartProducts[productIndex].amount + 1;
        } else {
          cartProducts[cartProducts.length] = {productId: productId, amount: 1, name: productName};
        }
      } else {
        cartProducts = [];
        cartProducts[0] = {productId: productId, amount: 1, name: productName};
      }
      localStorage.setItem("cart-products", JSON.stringify(cartProducts));
      buildCart();
    }

    document.querySelectorAll(".addCart").forEach(value => {
      value.onclick = function () {
        addToCart(this.dataset.productId, this.dataset.productName);
      }
    })

    function removeFromCart(productId) {
      console.log("Remove " + productId);
      let storageCartProducts = localStorage.getItem("cart-products");
      let cartProducts;
      if (storageCartProducts) {
        cartProducts = JSON.parse(storageCartProducts);
        let productIndex = cartProducts.findIndex(p => p.productId === productId);
        if (productIndex >= 0) {
          cartProducts.splice(productIndex, 1);
        }
      }
      localStorage.setItem("cart-products", JSON.stringify(cartProducts));
      buildCart();
    }

    function clearCart() {
      localStorage.removeItem("cart-products");
      buildCart();
    }

    function buildCart() {
      let storageCartProducts = localStorage.getItem("cart-products");
      let cartProducts = JSON.parse(storageCartProducts);
      if (!cartProducts) {
        let cartDiv = document.getElementById("shopping-cart").querySelector("div")
        cartDiv.innerHTML = '';
        document.getElementById("check-out-button").disabled = true;
        return;
      }
      document.getElementById("check-out-button").disabled = false;

      const tbl = document.createElement('table');
      tbl.style.width = '100%';
      tbl.style.border = "1px solid black";
      const tbody = document.createElement('tbody');
      tbl.appendChild(tbody);
      let cartDiv = document.getElementById("shopping-cart").querySelector("div")
      cartDiv.innerHTML = '';
      cartDiv.append(tbl);
      cartProducts.forEach(product => {
        let tr = document.createElement('tr');
        tr.style.border = "1px solid black";
        let td = document.createElement('td');
        td.style.border = "1px solid black";
        td.appendChild(document.createTextNode(product.productId))
        tr.appendChild(td)
        td = document.createElement('td');
        td.style.border = "1px solid black";
        td.appendChild(document.createTextNode(product.name))
        tr.appendChild(td)
        td = document.createElement('td');
        td.style.border = "1px solid black";
        td.appendChild(document.createTextNode(product.amount))
        tr.appendChild(td)
        td = document.createElement('td');
        td.style.border = "1px solid black";
        td.insertAdjacentHTML("afterbegin",
            `<button class='removeItemButton' data-product-id="${product.productId}" value='Remove item'>Remove item</button>`);
        tr.appendChild(td)
        tbody.appendChild(tr);
        console.log(product);

        document.querySelectorAll(".removeItemButton").forEach(value => {
          value.onclick = function () {
            removeFromCart(this.dataset.productId);
          }
        })
      })

      document.getElementById("check-out-button").onclick = function (e) {
        let storageCartProducts = localStorage.getItem("cart-products");
        let cartProducts = JSON.parse(storageCartProducts);
        if (!cartProducts) {
          alert("Empty cart.");
        }
        fetch('checkout', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(cartProducts),
        })
            .then(response => response.json())
            .then(data => {
              alert("Order id " + data.orderId + " Total money: " + data.totalMoney);
              clearCart();
            })
            .catch((error) => {
              console.error('Error:', error);
            });
        e.preventDefault();
      }
    }

    buildCart();
  }
})();