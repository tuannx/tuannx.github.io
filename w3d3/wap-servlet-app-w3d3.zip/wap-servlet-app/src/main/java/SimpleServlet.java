import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(value = "/simple", loadOnStartup = 1)
public class SimpleServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        ServletContext servletContext = this.getServletContext();
        PrintWriter writer = resp.getWriter();
        writer.println("<html><body>");
        writer.println("<h1>");
        writer.println(servletContext.getInitParameter("appname"));
        writer.println("</h1>");
        writer.println("<form method='POST'>");
        writer.println("<input type='Submit'>");
        writer.println("</form'>");
        writer.println("</body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        PrintWriter writer = resp.getWriter();
        writer.println("Hello from " + SimpleServlet.class.getName());
    }

    @Override
    public void init() throws ServletException {
        super.init();
        System.out.println("Init " + getClass().getName());
    }

    @Override
    public void destroy() {
        super.destroy();
        System.out.println("Destroy " + getClass().getName());
    }
}
