package w3d3;

import w3d3.model.User;
import w3d3.service.UserService;
import w3d3.service.UserServiceImpl;
import w3d3.util.CryptoUtil;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebFilter(urlPatterns = "/*")
public class LoginFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpServletRequest = (HttpServletRequest) request;
        if (httpServletRequest.getRequestURI().startsWith(httpServletRequest.getContextPath() + "/login")) {
            chain.doFilter(request, response);
            return;
        }
        if (httpServletRequest.getSession().getAttribute("user") == null) {
            HttpServletResponse httpServletResponse = (HttpServletResponse) response;
            String username = null;
            String password = null;
            for (Cookie cookie : httpServletRequest.getCookies()) {
                try {
                    if ("user".equals(cookie.getName())) {
                        username = CryptoUtil.decrypt(cookie.getValue());
                    } else if ("pass".equals(cookie.getName())) {
                        password = CryptoUtil.decrypt(cookie.getValue());
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (username != null && !username.isEmpty() && password != null && !password.isEmpty()) {
                UserService userService = new UserServiceImpl();
                User user = userService.login(username, password);
                if (user != null) {
                    httpServletRequest.getSession().setAttribute("user", user);
                    chain.doFilter(request, response);
                    return;
                }
            }
            httpServletRequest.getSession().setAttribute("message", "Invalid login.");
            httpServletResponse.sendRedirect(httpServletRequest.getContextPath() + "/login");
        }
        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {

    }
}
