package w3d3.service;

import w3d3.model.User;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserServiceImpl implements UserService {
    private static Map<String, User> userDatabase = new HashMap<>();

    static {
        List<User> users = new ArrayList<>();
        users.add(new User("user", "pass"));
        users.add(new User("sa", "18"));
        users.forEach(u -> {
            userDatabase.put(u.getUsername(), u);
        });
    }

    @Override
    public User login(String username, String password) {
        if (!userDatabase.containsKey(username)) {
            return null;
        }
        User user = userDatabase.get(username);
        if (user.getPassword().equals(password)) {
            return user;
        }
        return null;
    }
}
