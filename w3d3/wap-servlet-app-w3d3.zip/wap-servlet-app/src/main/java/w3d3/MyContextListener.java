package w3d3;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebListener;
import java.io.IOException;

@WebListener
public class MyContextListener implements ServletContextListener {
    @Override
    public void contextDestroyed(ServletContextEvent arg0) {
        System.out.println("Context Destroyed " + arg0.getServletContext().getContextPath());
    }

    @Override
    public void contextInitialized(ServletContextEvent arg0) {
        System.out.println("Context Initialized " + arg0.getServletContext().getContextPath());
    }
}