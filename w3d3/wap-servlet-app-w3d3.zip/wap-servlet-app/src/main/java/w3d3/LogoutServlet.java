package w3d3;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(value = "/logout")
public class LogoutServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.getSession().removeAttribute("user");
        PrintWriter writer = resp.getWriter();
        writer.write("<html>\n" +
                "<head>\n" +
                "    <title>Login</title>\n" +
                "</head>\n" +
                "<body>\n" +
                "<h1>Logout successfully</h1>\n" +
                "<a href='./login'>Login</a>\n" +
                "<a href='./'>Home</a>\n" +
                "</body>\n" +
                "</html>\n");
    }
}
