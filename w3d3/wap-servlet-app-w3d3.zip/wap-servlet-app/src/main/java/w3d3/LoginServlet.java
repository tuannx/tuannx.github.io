package w3d3;

import w3d3.model.User;
import w3d3.service.UserService;
import w3d3.service.UserServiceImpl;
import w3d3.util.CryptoUtil;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Objects;

@WebServlet(value = "/login")
public class LoginServlet extends HttpServlet {

    UserService userService = new UserServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String message = (String) req.getSession().getAttribute("message");
        req.getSession().removeAttribute("message");
        PrintWriter writer = resp.getWriter();
        writer.write("<html>\n" +
                "<head>\n" +
                "    <title>Login</title>\n" +
                "</head>\n" +
                "<body>\n" +
                "<h1>Login</h1>\n" +
                "<form method=\"post\" action=\"./login\">\n" +
                (message == null ? "" : "<label>" + message + "</label><br/>") +
                "    Username: <input name=\"username\" value=\"" + Objects.toString(req.getParameter("username"), "") + "\" required><br>\n" +
                "    Password: <input name=\"password\" type=\"password\" required><br>\n" +
                "    <label><input type=\"checkbox\" name=\"remember-me\">Remember me</label><br>\n" +
                "    <input type=\"submit\" value=\"Login\">\n" +
                "</form>\n" +
                "</body>\n" +
                "</html>\n");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        User user = userService.login(username, password);
        if (user == null) {
            req.getSession().setAttribute("message", "Invalid login.");
            doGet(req, resp);
            return;
        }
        if ("on".equalsIgnoreCase(req.getParameter("remember-me"))) {
            try {
                Cookie usernameCookie = new Cookie("user", CryptoUtil.encrypt(user.getUsername()));
                Cookie passwordCookie = new Cookie("pass", CryptoUtil.encrypt(user.getPassword()));
                usernameCookie.setMaxAge(30 * 24 * 60 * 60);
                passwordCookie.setMaxAge(30 * 24 * 60 * 60);
                resp.addCookie(usernameCookie);
                resp.addCookie(passwordCookie);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if ("off".equalsIgnoreCase(req.getParameter("remember-me"))) {
            try {
                Cookie usernameCookie = new Cookie("user", "");
                Cookie passwordCookie = new Cookie("pass", "");
                usernameCookie.setMaxAge(-1);
                passwordCookie.setMaxAge(-1);
                resp.addCookie(usernameCookie);
                resp.addCookie(passwordCookie);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        HttpSession session = req.getSession(); //creates new session if none exists
        session.isNew();
        session.setAttribute("user", user);
        PrintWriter writer = resp.getWriter();
        writer.write("<html>\n" +
                "<head>\n" +
                "    <title>Login</title>\n" +
                "</head>\n" +
                "<body>\n" +
                "<h1>Hello " + user.getUsername() + "</h1>\n" +
                "<a href='./logout'>Logout</a>\n" +
                "</body>\n" +
                "</html>\n");
    }
}
