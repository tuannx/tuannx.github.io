package w3d2;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.MessageFormat;
import java.util.UUID;

@WebServlet(value = "/support")
public class SupportServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        ServletContext servletContext = this.getServletContext();
        PrintWriter writer = resp.getWriter();
        writer.println("<html><body>");
        writer.println("<h1>");
        writer.println(servletContext.getInitParameter("appname"));
        writer.println("</h1>");
        writer.println("<form method='post'>");
        writer.println("Name: <input name='name'>");
        writer.println("<br>Email address: <input name='email'>");
        writer.println("<br>Problem: <input name='problem'>");
        writer.println("<br>Problem description: <textarea name='problem-description'></textarea>");
        writer.println("<br><input type='Submit' value='Help'>");
        writer.println("</form'>");
        writer.println("</body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        PrintWriter writer = resp.getWriter();
        String ticketId = UUID.randomUUID().toString();
        String msg = MessageFormat.format("Thank you! {0} for contacting us. We should receive reply from us with in 24 hrs in\n" +
                "your email address {1}. Let us know in our support email {2} if\n" +
                "you don’t receive reply within 24 hrs. Please be sure to attach your reference\n" +
                "{3} in your email.", req.getParameter("name"), req.getParameter("email"), ticketId, "support@miu.edu");
        writer.println(msg);
    }
}
